﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Net.Http;
using System.Net.Http.Headers;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;



namespace WpfApp1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public int Employee { get; private set; }
        //public object apdRequest { get; private set; }
        //public object data { get; private set; }

        public MainWindow()
        {
            InitializeComponent();
            EmployeeList();
        }
        private void EmployeeList()
        {
            HttpClient client = new HttpClient();
            client.BaseAddress = new Uri("https://gorest.co.in/public/");
            client.DefaultRequestHeaders.Accept.Clear();
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

            HttpResponseMessage awaitresponse = client.GetAsync("v2/users").Result;
            if (awaitresponse.IsSuccessStatusCode)
            {
                var employees1 = awaitresponse.Content.ReadAsAsync<IEnumerable<Employee>>().Result;
                gEmployee.ItemsSource = employees1;
            }
            else
            {
                MessageBox.Show("code error" + awaitresponse.StatusCode + ":" + awaitresponse.ReasonPhrase);
            }
        }

        private void BAdd_Click(object sender, RoutedEventArgs e)
        {

               HttpClient client = new HttpClient();
                client.BaseAddress = new Uri("https://gorest.co.in/public");
                client.DefaultRequestHeaders.Accept.Clear();
            string token = null;
            //client.DefaultRequestHeaders.Add("fa114107311259f5f33e70a5d85de34a2499b4401da069af0b1d835cd5ec0d56",token);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                var emp = new Employee();

                emp.Id = int.Parse(tId.Text);
                emp.Name = tName.Text;
                emp.Email = tEmail.Text;
                emp.Gender = tGender.Text;
                emp.Status = tStatus.Text;
                //object apdRequest = null;
                //var request2 = new HttpRequestMessage(HttpMethod.Post, "v2/users")
                //{
                //   Content = new StringContent(JsonConvert.SerializeObject(apdRequest), Encoding.UTF8,
                //"application/json")
                //};
                //var response = client.PostAsJsonAsync("v2/users", emp).Result;
                // var response = client.PostAsync("v2/users", emp).Result;
                //var response = client.SendAsync(request2).Result;

                //var url = "v2/users";
            var mycontent = JsonConvert.SerializeObject(emp);
            var buffer = System.Text.Encoding.UTF8.GetBytes(mycontent);
            var byteContent = new ByteArrayContent(buffer);
            byteContent.Headers.ContentType = new MediaTypeHeaderValue("application/json");
            var res = client.PostAsync("v2/users?access-token=fa114107311259f5f33e70a5d85de34a2499b4401da069af0b1d835cd5ec0d56", byteContent).Result;
            //HttpResponseMessage res = client.PostAsJsonAsync(url, new StringContent(JsonConvert.SerializeObject(emp),
            //Encoding.UTF8,
            //"application/json")).Result;
            //var Client = new HttpClient();
            //var res = client.PostAsJsonAsync(url,emp).Result;
            //bool returnValue =  res.Content.ReadAsAsync<bool>();
            //HttpResponseMessage res = client.PostAsJsonAsync(url, emp);                

            //Employee res = client.PostAsJsonAsync("v2/users?access-token=fa114107311259f5f33e70a5d85de34a2499b4401da069af0b1d835cd5ec0d56/",  new StringContent(JsonConvert.SerializeObject(emp)), Encoding.UTF8,
            //"application/json"));

            // var response = client.PostAsync("v2/users?access-token=fa114107311259f5f33e70a5d85de34a2499b4401da069af0b1d835cd5ec0d56", new StringContent(
            //new JavaScriptSerializer().Serialize(emp), Encoding.UTF8, "application/json")).Result;
            if (res.IsSuccessStatusCode)
                {
                    MessageBox.Show("New Employee added ");
                    tId.Text = "";
                    tName.Text = "";
                    tEmail.Text = "";
                    tGender.Text = "";
                    tStatus.Text = "";
                    EmployeeList();
                }
                else
                {
                    MessageBox.Show("code error" + res.StatusCode + ":" + res.ReasonPhrase);
                }
            


        }

        private void BDelete_Click(object sender, RoutedEventArgs e)
        {
            HttpClient client = new HttpClient();
            client.BaseAddress = new Uri("https://gorest.co.in/public/");
            client.DefaultRequestHeaders.Accept.Clear();
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
            var id = tId.Text.Trim();
            var url = "v2/users?access-token=fa114107311259f5f33e70a5d85de34a2499b4401da069af0b1d835cd5ec0d56" + id;
            HttpResponseMessage response = client.DeleteAsync(url).Result;

            if (response.IsSuccessStatusCode)
            {
                MessageBox.Show("User Deleted ");              
                EmployeeList();
            }
            else
            {
                MessageBox.Show("code error" + response.StatusCode + "message:" + response.ReasonPhrase);
            }

        }

        private void BSearch_Click(object sender, RoutedEventArgs e)
        {
            HttpClient client = new HttpClient();
            client.BaseAddress = new Uri("https://gorest.co.in/public/");          
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
            var id = tId.Text.Trim();
            var url = "v2/users/" + id;
            HttpResponseMessage response = client.GetAsync(url).Result;

            if (response.IsSuccessStatusCode)
            {
                //var employees1 = response.Content.ReadAsAsync<Employee>().Result;
                Employee employees1 = response.Content.ReadAsAsync<Employee>().Result;
               
                //return JsonConvert.DeserializeObject<List<OutputAddress>>(result);
                MessageBox.Show("User found :"+employees1.Name+" "+employees1.Email+" "+employees1.Status);
                //EmployeeList();
            }
            else
            {
                MessageBox.Show("code error" + response.StatusCode + "message:" + response.ReasonPhrase);
            }
        }
    }
}
